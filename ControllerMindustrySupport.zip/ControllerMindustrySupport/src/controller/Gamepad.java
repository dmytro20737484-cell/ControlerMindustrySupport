package controller;

/** Abstract gamepad. Indices follow SDL_GameController layout. */
public abstract class Gamepad{
    public static final int LX = 0, LY = 1, RX = 2, RY = 3, LT = 4, RT = 5;
    public static final int A = 0, B = 1, X = 2, Y = 3, BACK = 4, GUIDE = 5, START = 6,
        LS = 7, RS = 8, LB = 9, RB = 10, UP = 11, DOWN = 12, LEFT = 13, RIGHT = 14;

    public abstract void poll();
    /** Stick axes: -1..1. Triggers: 0..1. */
    public abstract float axis(int axis);
    public abstract boolean button(int button);
}
