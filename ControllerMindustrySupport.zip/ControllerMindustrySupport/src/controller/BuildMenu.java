package controller;

import arc.*;
import arc.graphics.*;
import arc.math.*;
import arc.struct.*;
import mindustry.*;
import mindustry.graphics.*;
import mindustry.type.*;
import mindustry.ui.dialogs.*;
import mindustry.world.*;

/** Gamepad build menu: X/Y change category, D-pad picks a block, A selects it, B closes. */
public class BuildMenu{
    static final int cols = 6;

    BaseDialog dialog;
    final Seq<Category> cats = new Seq<>();
    final Seq<Block> blocks = new Seq<>();
    int cat, sel;
    boolean open;

    public boolean isOpen(){
        return open;
    }

    private Seq<Block> blocksIn(Category c){
        return Vars.content.blocks().select(b -> b.category == c && b.isVisible() && b.unlockedNow());
    }

    public void open(){
        cats.clear();
        for(Category c : Category.values()){
            if(blocksIn(c).size > 0) cats.add(c);
        }
        if(cats.isEmpty()) return;

        if(dialog == null){
            dialog = new BaseDialog(Binds.tr("Build menu", "Меню будування"));
            dialog.addCloseButton();
            dialog.hidden(() -> open = false);
        }

        cat = Mathf.clamp(cat, 0, cats.size - 1);
        sel = 0;
        load();
        rebuild();
        open = true;
        dialog.show();
    }

    public void close(){
        open = false;
        if(dialog != null) dialog.hide();
    }

    private void load(){
        blocks.clear();
        blocks.addAll(blocksIn(cats.get(cat)));
        sel = Mathf.clamp(sel, 0, Math.max(0, blocks.size - 1));
    }

    public void update(GamepadUi ui){
        if(cats.isEmpty()) return;

        boolean dirty = false;
        int n = cats.size;
        if(ui.pressed(Binds.Action.catPrev)){
            cat = (cat + n - 1) % n;
            sel = 0;
            load();
            dirty = true;
        }
        if(ui.pressed(Binds.Action.catNext)){
            cat = (cat + 1) % n;
            sel = 0;
            load();
            dirty = true;
        }

        int old = sel;
        if(ui.dpad(Gamepad.LEFT)) sel--;
        if(ui.dpad(Gamepad.RIGHT)) sel++;
        if(ui.dpad(Gamepad.UP)) sel -= cols;
        if(ui.dpad(Gamepad.DOWN)) sel += cols;
        sel = Mathf.clamp(sel, 0, Math.max(0, blocks.size - 1));
        if(sel != old) dirty = true;

        if(dirty) rebuild();

        if(ui.pressed(Binds.Action.click) && blocks.size > 0){
            Vars.control.input.block = blocks.get(sel);
            close();
        }else if(ui.pressed(Binds.Action.back)){
            close();
        }
    }

    private void rebuild(){
        dialog.cont.clear();

        dialog.cont.table(row -> {
            for(int i = 0; i < cats.size; i++){
                Category c = cats.get(i);
                row.add(Core.bundle.get("category." + c.name())).color(i == cat ? Pal.accent : Color.gray).pad(8f);
            }
        }).padBottom(12f).row();

        dialog.cont.table(grid -> {
            for(int i = 0; i < blocks.size; i++){
                final int idx = i;
                Block b = blocks.get(i);
                grid.table(cell -> {
                    cell.image(b.uiIcon).size(46f);
                    cell.row();
                    cell.image().color(idx == sel ? Pal.accent : Color.clear).height(4f).growX();
                }).pad(6f);
                if((i + 1) % cols == 0) grid.row();
            }
        }).row();

        if(blocks.size > 0){
            dialog.cont.add(blocks.get(sel).localizedName).color(Pal.accent).padTop(12f).row();
        }

        dialog.cont.add(Binds.name(Binds.get(Binds.Action.catPrev)) + " / " + Binds.name(Binds.get(Binds.Action.catNext))
            + ": " + Binds.tr("category", "категорія")).color(Color.lightGray).padTop(8f).row();
        dialog.cont.add(Binds.tr("D-pad: choose block", "Хрестовина: вибір блоку")).color(Color.lightGray).row();
        dialog.cont.add(Binds.name(Binds.get(Binds.Action.click)) + ": " + Binds.tr("select", "обрати")
            + "   " + Binds.name(Binds.get(Binds.Action.back)) + ": " + Binds.tr("close", "закрити")).color(Color.lightGray).row();
    }
}
