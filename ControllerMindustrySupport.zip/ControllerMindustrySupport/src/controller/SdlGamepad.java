package controller;

import arc.util.*;

import java.lang.reflect.*;

/**
 * Reads the first connected controller through Arc's bundled SDL bindings (via reflection,
 * so the mod still loads if the bindings differ). Returns null from tryCreate() if unavailable.
 */
public class SdlGamepad extends Gamepad{
    private final Class<?> sdl;
    private final Method getAxis, getButton, update;
    private final long handle;
    private String devName = "";

    private SdlGamepad(Class<?> sdl, Method getAxis, Method getButton, Method update, long handle){
        this.sdl = sdl;
        this.getAxis = getAxis;
        this.getButton = getButton;
        this.update = update;
        this.handle = handle;
    }

    private static Method find(Class<?> c, String name, int params){
        for(Method m : c.getMethods()){
            if(m.getName().equals(name) && m.getParameterCount() == params) return m;
        }
        return null;
    }

    public static SdlGamepad tryCreate(){
        try{
            Class<?> sdl = Class.forName("arc.backend.sdl.jni.SDL");
            Method init = find(sdl, "SDL_InitSubSystem", 1);
            if(init != null) init.invoke(null, 0x2000); // SDL_INIT_GAMECONTROLLER

            Method num = find(sdl, "SDL_NumJoysticks", 0);
            Method open = find(sdl, "SDL_GameControllerOpen", 1);
            Method axis = find(sdl, "SDL_GameControllerGetAxis", 2);
            Method button = find(sdl, "SDL_GameControllerGetButton", 2);
            Method update = find(sdl, "SDL_GameControllerUpdate", 0);
            if(num == null || open == null || axis == null || button == null){
                Log.warn("[controller] SDL gamepad methods not found in this Arc build.");
                return null;
            }

            int count = ((Number)num.invoke(null)).intValue();
            for(int i = 0; i < count; i++){
                Object h = open.invoke(null, i);
                long handle = ((Number)h).longValue();
                if(handle != 0){
                    Log.info("[controller] Opened gamepad @", i);
                    SdlGamepad pad = new SdlGamepad(sdl, axis, button, update, handle);
                    try{
                        Method nm = find(sdl, "SDL_GameControllerName", 1);
                        if(nm != null){
                            Object r = nm.invoke(null, handle);
                            if(r != null) pad.devName = String.valueOf(r);
                        }
                    }catch(Throwable ignored){}
                    return pad;
                }
            }
            Log.info("[controller] No gamepad connected.");
        }catch(Throwable t){
            Log.warn("[controller] SDL init failed: @", t.toString());
        }
        return null;
    }

    @Override
    public String name(){
        return devName;
    }

    @Override
    public void poll(){
        try{
            if(update != null) update.invoke(null);
        }catch(Throwable ignored){}
    }

    @Override
    public float axis(int axis){
        try{
            float v = ((Number)getAxis.invoke(null, handle, axis)).floatValue() / 32767f;
            return Math.max(-1f, Math.min(1f, v));
        }catch(Throwable t){
            return 0f;
        }
    }

    @Override
    public boolean button(int button){
        try{
            return ((Number)getButton.invoke(null, handle, button)).intValue() != 0;
        }catch(Throwable t){
            return false;
        }
    }
}
