# ControllerMindustrySupport (Mindustry mod, v8 build 160.7) - PC + Android

Controls: left stick = move, right stick = aim, RT = shoot, LB/RB = zoom out/in, Start = pause menu.
Building blocks is NOT yet gamepad-driven.

## Build
PC only:        gradle jar      -> build/libs/ControllerMindustrySupportDesktop.jar
PC + Android:   gradle deploy   -> build/libs/ControllerMindustrySupport.jar  (needs ANDROID_HOME pointing to the Android SDK)
Put the jar into Mindustry's `mods` folder (on Android: import via Mods -> Import Mod).

## How the pad is read
- PC: Arc's bundled SDL bindings (via reflection).
- Android: a hook on the Activity's Window.Callback (joystick motion + gamepad keys). Pair the pad over Bluetooth/USB first.

## Notes
- Written without being compiled or tested. If compile errors appear, they will most likely be method names for your exact Mindustry version.
- If PC log says "SDL gamepad methods not found", use Steam Input (keyboard+mouse template) as a fallback.

## Build via GitHub (no local setup)
1. Create a new GitHub repository and upload everything from this folder (keep the .github folder).
2. Open the Actions tab -> "Build mod" -> wait for the green check.
3. Open the finished run -> Artifacts -> download ControllerMindustrySupport (a zip containing ControllerMindustrySupport.jar).
4. PC: put the jar into the Mindustry `mods` folder. Android: Mods -> Import Mod.
If the run fails, open the failed step and send the error text.
