package controller;

import android.app.*;
import android.view.*;
import arc.*;
import arc.util.*;

import java.lang.reflect.*;

/**
 * Android gamepad input. Hooks the Activity's Window.Callback so joystick motion events and
 * gamepad key events reach us before the game's own input handling.
 */
public class AndroidGamepad extends Gamepad{
    private final float[] axes = new float[6];
    private final boolean[] buttons = new boolean[15];

    private static AndroidGamepad instance;

    private volatile String devName = "";

    private AndroidGamepad(){}

    @Override
    public String name(){
        return devName;
    }

    private void remember(InputEvent e){
        InputDevice d = e.getDevice();
        if(d != null && d.getName() != null) devName = d.getName();
    }

    public static AndroidGamepad tryCreate(){
        if(instance != null) return instance;
        try{
            Object app = Core.app;
            if(!(app instanceof Activity)){
                Log.warn("[controller] Core.app is not an Activity, Android gamepad unavailable.");
                return null;
            }
            final Activity activity = (Activity)app;
            final AndroidGamepad pad = new AndroidGamepad();

            activity.runOnUiThread(() -> {
                try{
                    Window window = activity.getWindow();
                    final Window.Callback orig = window.getCallback();
                    Window.Callback proxy = (Window.Callback)Proxy.newProxyInstance(
                        Window.class.getClassLoader(), new Class[]{Window.Callback.class},
                        (p, m, args) -> {
                            String n = m.getName();
                            if(n.equals("dispatchGenericMotionEvent") && pad.onMotion((MotionEvent)args[0])) return true;
                            if(n.equals("dispatchKeyEvent") && pad.onKey((KeyEvent)args[0])) return true;
                            try{
                                return m.invoke(orig, args);
                            }catch(InvocationTargetException e){
                                throw e.getCause();
                            }
                        });
                    window.setCallback(proxy);
                    Log.info("[controller] Android gamepad hook installed.");
                }catch(Throwable t){
                    Log.warn("[controller] Android hook failed: @", t.toString());
                }
            });
            instance = pad;
            return pad;
        }catch(Throwable t){
            Log.warn("[controller] Android gamepad init failed: @", t.toString());
            return null;
        }
    }

    private static float stick(MotionEvent e, int axis){
        return e.getAxisValue(axis);
    }

    private static float pick(float a, float b){
        return Math.abs(a) >= Math.abs(b) ? a : b;
    }

    boolean onMotion(MotionEvent e){
        remember(e);
        if((e.getSource() & InputDevice.SOURCE_JOYSTICK) == 0 || e.getAction() != MotionEvent.ACTION_MOVE) return false;

        axes[LX] = stick(e, MotionEvent.AXIS_X);
        axes[LY] = stick(e, MotionEvent.AXIS_Y);
        // Right stick is AXIS_Z/AXIS_RZ on most pads, AXIS_RX/AXIS_RY on some.
        axes[RX] = pick(stick(e, MotionEvent.AXIS_Z), stick(e, MotionEvent.AXIS_RX));
        axes[RY] = pick(stick(e, MotionEvent.AXIS_RZ), stick(e, MotionEvent.AXIS_RY));
        axes[LT] = Math.max(stick(e, MotionEvent.AXIS_LTRIGGER), stick(e, MotionEvent.AXIS_BRAKE));
        axes[RT] = Math.max(stick(e, MotionEvent.AXIS_RTRIGGER), stick(e, MotionEvent.AXIS_GAS));

        float hx = stick(e, MotionEvent.AXIS_HAT_X), hy = stick(e, MotionEvent.AXIS_HAT_Y);
        buttons[LEFT] = hx < -0.5f;
        buttons[RIGHT] = hx > 0.5f;
        buttons[UP] = hy < -0.5f;
        buttons[DOWN] = hy > 0.5f;
        return true;
    }

    boolean onKey(KeyEvent e){
        remember(e);
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        int idx = -1;
        switch(code){
            case KeyEvent.KEYCODE_BUTTON_A: idx = A; break;
            case KeyEvent.KEYCODE_BUTTON_B: idx = B; break;
            case KeyEvent.KEYCODE_BUTTON_X: idx = X; break;
            case KeyEvent.KEYCODE_BUTTON_Y: idx = Y; break;
            case KeyEvent.KEYCODE_BUTTON_SELECT: idx = BACK; break;
            case KeyEvent.KEYCODE_BUTTON_START: idx = START; break;
            case KeyEvent.KEYCODE_BUTTON_THUMBL: idx = LS; break;
            case KeyEvent.KEYCODE_BUTTON_THUMBR: idx = RS; break;
            case KeyEvent.KEYCODE_BUTTON_L1: idx = LB; break;
            case KeyEvent.KEYCODE_BUTTON_R1: idx = RB; break;
            case KeyEvent.KEYCODE_BUTTON_L2: axes[LT] = down ? 1f : 0f; return true;
            case KeyEvent.KEYCODE_BUTTON_R2: axes[RT] = down ? 1f : 0f; return true;
        }
        if(idx < 0) return false;
        buttons[idx] = down;
        return true;
    }

    @Override public void poll(){}

    @Override
    public float axis(int axis){
        return axes[axis];
    }

    @Override
    public boolean button(int button){
        return buttons[button];
    }
}
