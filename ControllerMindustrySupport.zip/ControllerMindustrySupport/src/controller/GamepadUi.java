package controller;

import arc.*;
import arc.graphics.*;
import arc.graphics.g2d.*;
import arc.input.*;
import arc.math.*;
import arc.math.geom.*;
import arc.scene.*;
import arc.scene.event.*;
import arc.scene.ui.*;
import arc.struct.*;
import arc.util.*;
import mindustry.*;
import mindustry.graphics.*;

/**
 * Gamepad navigation for menus and the HUD: a cursor on the aim stick, D-pad snapping between buttons,
 * click / back buttons, and the gamepad build menu.
 */
public class GamepadUi{
    final BuildMenu build = new BuildMenu();
    Gamepad pad;

    float cx, cy;
    boolean ready, manualCursor, held, shown, cursorMode;
    Element cursorEl;

    final Binds.Action[] actions = Binds.Action.values();
    final boolean[] now = new boolean[actions.length], prev = new boolean[actions.length];
    final boolean[] dprev = new boolean[4], dfire = new boolean[4];
    final float[] hold = new float[4];

    public void init(){
        cursorEl = new Element(){
            @Override
            public void draw(){
                if(!shown) return;
                Vec2 p = Core.scene.screenToStageCoordinates(Tmp.v3.set(cx, cy));
                Draw.color(Color.black);
                Fill.circle(p.x, p.y, 7f);
                Draw.color(Color.white);
                Fill.circle(p.x, p.y, 5f);
                Draw.color(Pal.accent);
                Lines.stroke(2f);
                Lines.circle(p.x, p.y, 12f);
                Draw.reset();
            }
        };
        cursorEl.touchable = Touchable.disabled;
        Core.scene.add(cursorEl);
    }

    public boolean cursorMode(){
        return cursorMode;
    }

    // ---- per-frame input edges ----

    public void begin(Gamepad pad){
        this.pad = pad;
        for(int i = 0; i < actions.length; i++){
            prev[i] = now[i];
            now[i] = Binds.down(pad, actions[i]);
        }
        for(int i = 0; i < 4; i++){
            boolean d = pad.button(Gamepad.UP + i);
            boolean fire = false;
            if(d){
                if(!dprev[i]){
                    hold[i] = 0f;
                    fire = true;
                }else{
                    hold[i] += Binds.delta();
                    if(hold[i] > 26f){
                        hold[i] -= 7f;
                        fire = true;
                    }
                }
            }
            dprev[i] = d;
            dfire[i] = fire;
        }
    }

    public boolean pressed(Binds.Action a){
        return now[a.ordinal()] && !prev[a.ordinal()];
    }

    public boolean released(Binds.Action a){
        return !now[a.ordinal()] && prev[a.ordinal()];
    }

    /** D-pad press with auto-repeat. id is Gamepad.UP/DOWN/LEFT/RIGHT. */
    public boolean dpad(int id){
        return dfire[id - Gamepad.UP];
    }

    float dz(float v){
        return Math.abs(v) < Binds.deadzone() ? 0f : v;
    }

    // ---- main update ----

    public void update(){
        boolean inGame = Vars.state.isGame();
        boolean dialog = Core.scene.hasDialog();
        boolean blockSel = inGame && Vars.control.input.block != null;

        if(pressed(Binds.Action.cursor)) manualCursor = !manualCursor;
        cursorMode = !inGame || dialog || manualCursor || blockSel;

        // build menu
        boolean wasOpen = build.isOpen();
        if(inGame && !dialog && !wasOpen && pressed(Binds.Action.build)){
            build.open();
            wasOpen = true;
        }else if(wasOpen){
            if(pressed(Binds.Action.build)) build.close();
            else build.update(this);
        }
        if(wasOpen){
            shown = false;
            return;
        }

        if(!ready){
            cx = Core.graphics.getWidth() / 2f;
            cy = Core.graphics.getHeight() / 2f;
            ready = true;
        }

        shown = cursorMode;
        if(!cursorMode){
            if(held){
                touch(false);
                held = false;
            }
            return;
        }
        if(cursorEl != null) cursorEl.toFront();

        boolean moved = false;

        // cursor follows the aim stick
        boolean swap = Binds.swapSticks();
        float sx = dz(Binds.stick(pad, swap ? Gamepad.LX : Gamepad.RX));
        float sy = dz(Binds.stick(pad, swap ? Gamepad.LY : Gamepad.RY));
        if(sx != 0f || sy != 0f){
            float sp = Binds.cursorSpeed() * Binds.delta();
            cx = Mathf.clamp(cx + sx * sp, 0f, Core.graphics.getWidth() - 1f);
            cy = Mathf.clamp(cy + sy * sp, 0f, Core.graphics.getHeight() - 1f);
            moved = true;
        }

        // D-pad jumps to the nearest button in that direction
        int dx = 0, dy = 0;
        if(dpad(Gamepad.UP)) dy = -1;
        else if(dpad(Gamepad.DOWN)) dy = 1;
        else if(dpad(Gamepad.LEFT)) dx = -1;
        else if(dpad(Gamepad.RIGHT)) dx = 1;
        if((dx != 0 || dy != 0) && navigate(dx, dy)) moved = true;

        if(moved) move();

        // click (hold to drag / scroll)
        if(pressed(Binds.Action.click)){
            touch(true);
            held = true;
        }
        if(held && released(Binds.Action.click)){
            touch(false);
            held = false;
        }

        if(pressed(Binds.Action.back)) goBack();
    }

    void goBack(){
        if(Core.scene.hasDialog()){
            key(KeyCode.escape);
        }else if(Vars.state.isGame() && Vars.control.input.block != null){
            Vars.control.input.block = null;
        }else{
            manualCursor = false;
        }
    }

    // ---- navigation between buttons ----

    boolean navigate(int dx, int dy){
        Seq<Element> list = new Seq<>();
        collect(Core.scene.root, list);

        Element best = null;
        float bestScore = Float.MAX_VALUE, bx = 0f, by = 0f;
        Vec2 tmp = new Vec2();
        for(Element e : list){
            center(e, tmp);
            float vx = tmp.x - cx, vy = tmp.y - cy;
            float along = vx * dx + vy * dy;
            if(along < 6f) continue;
            float perp = Math.abs(vx * dy - vy * dx);
            float score = along + perp * 2f;
            if(score < bestScore){
                bestScore = score;
                best = e;
                bx = tmp.x;
                by = tmp.y;
            }
        }
        if(best == null) return false;
        cx = bx;
        cy = by;
        return true;
    }

    void collect(Element e, Seq<Element> out){
        if(e == null || !e.visible) return;
        if(e instanceof Button && !((Button)e).isDisabled() && onTop(e)){
            out.add(e);
        }
        if(e instanceof Group){
            ((Group)e).getChildren().each(c -> collect(c, out));
        }
    }

    /** Screen-space (y from top) centre of an element. */
    void center(Element e, Vec2 out){
        out.set(e.getWidth() / 2f, e.getHeight() / 2f);
        e.localToStageCoordinates(out);
        Core.scene.stageToScreenCoordinates(out);
    }

    /** True if nothing (e.g. a dialog) covers the middle of this element. */
    boolean onTop(Element e){
        Vec2 c = new Vec2();
        center(e, c);
        Vec2 st = Core.scene.screenToStageCoordinates(new Vec2(c.x, c.y));
        Element h = Core.scene.hit(st.x, st.y, true);
        return h != null && (h == e || h.isDescendantOf(e));
    }

    // ---- fake pointer events ----

    private Seq<InputProcessor> processors(){
        return new Seq<>(Core.input.getInputProcessors());
    }

    void touch(boolean down){
        int x = (int)cx, y = (int)cy;
        for(InputProcessor p : processors()){
            boolean r = down ? p.touchDown(x, y, 0, KeyCode.mouseLeft) : p.touchUp(x, y, 0, KeyCode.mouseLeft);
            if(r) break;
        }
    }

    void move(){
        int x = (int)cx, y = (int)cy;
        for(InputProcessor p : processors()){
            boolean r = held ? p.touchDragged(x, y, 0) : p.mouseMoved(x, y);
            if(r) break;
        }
    }

    void key(KeyCode k){
        for(InputProcessor p : processors()){
            if(p.keyDown(k)) break;
        }
        for(InputProcessor p : processors()){
            if(p.keyUp(k)) break;
        }
    }
}
