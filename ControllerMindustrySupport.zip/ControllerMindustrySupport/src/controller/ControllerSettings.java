package controller;

import arc.*;
import arc.graphics.*;
import arc.scene.ui.*;
import arc.scene.ui.layout.*;
import arc.util.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.ui.*;
import mindustry.ui.dialogs.*;
import mindustry.ui.dialogs.SettingsMenuDialog.SettingsTable;
import mindustry.ui.dialogs.SettingsMenuDialog.SettingsTable.Setting;

/** Adds a "Controller" tab to the settings dialog: layout, bindings, sticks and a live tester. */
public class ControllerSettings{
    private final ControllerMod mod;

    public ControllerSettings(ControllerMod mod){
        this.mod = mod;
    }

    public void init(){
        mindustry.Vars.ui.settings.addCategory(Binds.tr("Controller", "Геймпад"), Icon.settings, t -> {
            t.pref(new Setting("cms-panel"){
                @Override
                public void add(SettingsTable table){
                    table.add(build()).growX().left().row();
                }
            });
        });
    }

    private float val(int axis){
        return mod.pad == null ? 0f : mod.pad.axis(axis);
    }

    private Bar bar(String name, int axis, boolean signed){
        return new Bar(
            () -> name + "  " + Strings.fixed(val(axis), 2),
            () -> Pal.accent,
            () -> signed ? (val(axis) + 1f) / 2f : val(axis)
        );
    }

    private Table build(){
        Table c = new Table();
        c.left().defaults().left().pad(4f);

        // keep the pad state fresh while this tab is visible
        c.update(() -> {
            if(mod.pad != null) mod.pad.poll();
        });

        // ---- status ----
        Label status = new Label("");
        status.update(() -> status.setText(mod.pad == null
            ? Binds.tr("No controller detected", "Геймпад не знайдено")
            : Binds.tr("Controller connected", "Геймпад підключено")));
        c.add(status).left().row();
        c.button(Binds.tr("Reconnect", "Перепідключити"), mod::reconnect).size(260f, 50f).left().row();

        // ---- layout ----
        TextButton layout = new TextButton("");
        layout.clicked(() -> Core.settings.put("cms-layout", (Binds.layout() + 1) % Binds.layouts.length));
        layout.update(() -> layout.setText(Binds.tr("Layout: ", "Розкладка: ") + Binds.layouts[Binds.layout()]));
        c.add(layout).size(320f, 50f).left().row();

        // ---- bindings ----
        c.add(Binds.tr("Buttons (tap to change)", "Кнопки (натисни, щоб змінити)")).color(Pal.accent).padTop(12f).left().row();
        for(Binds.Action a : Binds.Action.values()){
            c.table(r -> {
                r.left();
                r.add(a.title()).width(170f).left();
                TextButton b = new TextButton("");
                b.update(() -> b.setText(Binds.name(Binds.get(a))));
                b.clicked(() -> rebind(a));
                r.add(b).size(170f, 46f);
            }).left().row();
        }
        c.button(Binds.tr("Reset buttons", "Скинути кнопки"), Binds::resetBindings).size(260f, 46f).left().row();

        // ---- sticks ----
        c.add(Binds.tr("Sticks", "Стіки")).color(Pal.accent).padTop(12f).left().row();
        slider(c, Binds.tr("Dead zone", "Мертва зона"), "cms-deadzone", 22, 5, 50, 1, "%");
        slider(c, Binds.tr("Aim distance", "Дальність прицілу"), "cms-aimrange", 260, 100, 600, 10, "");
        slider(c, Binds.tr("Move / camera speed", "Швидкість руху / камери"), "cms-speed", 100, 50, 200, 5, "%");
        slider(c, Binds.tr("Cursor speed", "Швидкість курсора"), "cms-cursorspeed", 100, 30, 300, 5, "%");
        c.check(Binds.tr("Swap sticks (left aims, right moves)", "Поміняти стіки місцями (лівий цілиться)"),
            Binds.swapSticks(), v -> Core.settings.put("cms-swap", v)).left().row();

        // ---- tester ----
        c.add(Binds.tr("Controller test", "Тест геймпада")).color(Pal.accent).padTop(12f).left().row();
        c.add(bar(Binds.tr("Left X", "Лівий X"), Gamepad.LX, true)).size(320f, 30f).left().row();
        c.add(bar(Binds.tr("Left Y", "Лівий Y"), Gamepad.LY, true)).size(320f, 30f).left().row();
        c.add(bar(Binds.tr("Right X", "Правий X"), Gamepad.RX, true)).size(320f, 30f).left().row();
        c.add(bar(Binds.tr("Right Y", "Правий Y"), Gamepad.RY, true)).size(320f, 30f).left().row();
        c.add(bar(Binds.name(Binds.LT_ID), Gamepad.LT, false)).size(320f, 30f).left().row();
        c.add(bar(Binds.name(Binds.RT_ID), Gamepad.RT, false)).size(320f, 30f).left().row();

        int[] ids = {Gamepad.A, Gamepad.B, Gamepad.X, Gamepad.Y, Gamepad.LB, Gamepad.RB, Gamepad.BACK, Gamepad.START,
            Gamepad.LS, Gamepad.RS, Gamepad.UP, Gamepad.DOWN, Gamepad.LEFT, Gamepad.RIGHT};
        c.table(g -> {
            g.left();
            int n = 0;
            for(int id : ids){
                Label l = new Label("");
                l.update(() -> {
                    l.setText(Binds.name(id));
                    l.setColor(mod.pad != null && mod.pad.button(id) ? Color.lime : Color.gray);
                });
                g.add(l).width(110f).pad(6f).left();
                if(++n % 3 == 0) g.row();
            }
        }).left().row();

        return c;
    }

    private void slider(Table t, String title, String key, int def, int min, int max, int step, String suffix){
        Slider s = new Slider(min, max, step, false);
        s.setValue(Core.settings.getInt(key, def));
        Label v = new Label(Core.settings.getInt(key, def) + suffix);
        s.moved(val -> {
            Core.settings.put(key, (int)val);
            v.setText((int)val + suffix);
        });
        t.add(title).left().row();
        t.table(r -> {
            r.left();
            r.add(s).width(240f);
            r.add(v).padLeft(10f);
        }).left().row();
    }

    private void rebind(Binds.Action a){
        BaseDialog d = new BaseDialog(Binds.tr("Change button", "Зміна кнопки") + ": " + a.title());
        d.cont.add(Binds.tr("Press a button or trigger on the controller...", "Натисни кнопку або тригер на геймпаді...")).row();
        d.addCloseButton();

        final boolean[] armed = {false};
        d.update(() -> {
            if(mod.pad == null) return;
            mod.pad.poll();
            int id = Binds.firstDown(mod.pad);
            if(id == -1){
                armed[0] = true; // wait until everything is released first
                return;
            }
            if(!armed[0]) return;
            Binds.set(a, id);
            d.hide();
        });
        Binds.capturing = true;
        d.hidden(() -> Binds.capturing = false);
        d.show();
    }
}
