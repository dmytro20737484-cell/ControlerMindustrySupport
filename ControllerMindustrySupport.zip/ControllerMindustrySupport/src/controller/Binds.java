package controller;

import arc.*;

import java.util.*;

/** Binding ids, layouts (Xbox / PlayStation labels) and saved settings. */
public class Binds{
    /** Ids 0..14 are Gamepad buttons; triggers get their own ids. */
    public static final int LT_ID = 20, RT_ID = 21;
    public static final String[] layouts = {"Auto", "Xbox", "PlayStation"};
    /** Set by the mod so labels can follow the connected controller. */
    public static Gamepad current;

    private static final String[] xbox = new String[22], ps = new String[22];

    static{
        fill(xbox, "A", "B", "X", "Y", "View", "Xbox", "Menu", "LB", "RB", "LT", "RT");
        fill(ps, "Cross", "Circle", "Square", "Triangle", "Share", "PS", "Options", "L1", "R1", "L2", "R2");
    }

    private static void fill(String[] n, String a, String b, String x, String y, String back, String guide,
                             String start, String lb, String rb, String lt, String rt){
        n[Gamepad.A] = a;
        n[Gamepad.B] = b;
        n[Gamepad.X] = x;
        n[Gamepad.Y] = y;
        n[Gamepad.BACK] = back;
        n[Gamepad.GUIDE] = guide;
        n[Gamepad.START] = start;
        n[Gamepad.LS] = "L3";
        n[Gamepad.RS] = "R3";
        n[Gamepad.LB] = lb;
        n[Gamepad.RB] = rb;
        n[Gamepad.UP] = "D-pad Up";
        n[Gamepad.DOWN] = "D-pad Down";
        n[Gamepad.LEFT] = "D-pad Left";
        n[Gamepad.RIGHT] = "D-pad Right";
        n[LT_ID] = lt;
        n[RT_ID] = rt;
    }

    public enum Action{
        shoot("Shoot", "Стрільба", RT_ID),
        zoomOut("Zoom out", "Віддалити", Gamepad.LB),
        zoomIn("Zoom in", "Наблизити", Gamepad.RB),
        menu("Pause menu", "Меню паузи", Gamepad.START),
        click("Click / select", "Клік / вибір", Gamepad.A),
        back("Back / cancel", "Назад / скасувати", Gamepad.B),
        cursor("Cursor mode on/off", "Курсор вкл/викл", Gamepad.RS),
        build("Build menu", "Меню будування", Gamepad.BACK),
        catPrev("Previous category", "Попередня категорія", Gamepad.X),
        catNext("Next category", "Наступна категорія", Gamepad.Y);

        public final String en, uk;
        public final int def;

        Action(String en, String uk, int def){
            this.en = en;
            this.uk = uk;
            this.def = def;
        }

        public String key(){
            return "cms-bind-" + name();
        }

        public String title(){
            return tr(en, uk);
        }
    }

    public static boolean ukrainian(){
        String l = Core.settings.getString("locale", "default");
        if(l.equals("default")) l = Locale.getDefault().getLanguage();
        return l.startsWith("uk");
    }

    public static String tr(String en, String uk){
        return ukrainian() ? uk : en;
    }

    public static int layout(){
        return Math.max(0, Math.min(layouts.length - 1, Core.settings.getInt("cms-layout", 0)));
    }

    public static boolean isPlayStation(){
        int m = layout();
        if(m == 1) return false;
        if(m == 2) return true;
        String n = current == null ? "" : current.name().toLowerCase();
        return n.contains("playstation") || n.contains("dualshock") || n.contains("dualsense")
            || n.contains("sony") || n.contains("ps4") || n.contains("ps5") || n.contains("wireless controller");
    }

    public static String name(int id){
        String[] n = isPlayStation() ? ps : xbox;
        return id >= 0 && id < n.length && n[id] != null ? n[id] : "?";
    }

    public static int get(Action a){
        return Core.settings.getInt(a.key(), a.def);
    }

    public static void set(Action a, int id){
        Core.settings.put(a.key(), id);
    }

    public static void resetBindings(){
        for(Action a : Action.values()) Core.settings.remove(a.key());
    }

    public static boolean down(Gamepad pad, int id){
        if(pad == null) return false;
        if(id == LT_ID) return pad.axis(Gamepad.LT) > 0.3f;
        if(id == RT_ID) return pad.axis(Gamepad.RT) > 0.3f;
        return id >= 0 && id <= Gamepad.RIGHT && pad.button(id);
    }

    public static boolean down(Gamepad pad, Action a){
        return down(pad, get(a));
    }

    /** First pressed button/trigger id, or -1. */
    public static int firstDown(Gamepad pad){
        if(pad == null) return -1;
        for(int i = 0; i <= Gamepad.RIGHT; i++){
            if(pad.button(i)) return i;
        }
        if(down(pad, LT_ID)) return LT_ID;
        if(down(pad, RT_ID)) return RT_ID;
        return -1;
    }

    /** True while the rebind dialog is open, so button presses are not treated as game input. */
    public static boolean capturing;

    /** Frame delta in 60fps ticks that keeps ticking while the game is paused or in menus. */
    public static float delta(){
        return Math.min(Core.graphics.getDeltaTime() * 60f, 3f);
    }

    public static float cursorSpeed(){
        return Core.settings.getInt("cms-cursorspeed", 100) / 100f * 14f;
    }

    public static float deadzone(){
        return Core.settings.getInt("cms-deadzone", 22) / 100f;
    }

    public static float aimRange(){
        return Core.settings.getInt("cms-aimrange", 260);
    }

    public static float speedScale(){
        return Core.settings.getInt("cms-speed", 100) / 100f;
    }

    public static boolean swapSticks(){
        return Core.settings.getBool("cms-swap", false);
    }
}
