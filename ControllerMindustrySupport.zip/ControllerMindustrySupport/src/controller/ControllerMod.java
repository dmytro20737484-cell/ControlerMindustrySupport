package controller;

import arc.*;
import arc.util.*;
import mindustry.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.mod.*;

public class ControllerMod extends Mod{
    static final float zoomSpeed = 0.03f;

    public Gamepad pad;
    boolean prevMenu, prevShoot;
    float retryTimer;

    public ControllerMod(){
        Events.on(ClientLoadEvent.class, e -> {
            pad = Binds.current = create();
            try{
                new ControllerSettings(this).init();
            }catch(Throwable t){
                Log.err("[controller] Could not add settings tab", t);
            }
        });

        // preDraw runs after the game's own input handling, so our values win over the keyboard's zeros.
        Events.run(Trigger.preDraw, this::tick);
    }

    static Gamepad create(){
        return OS.isAndroid ? AndroidGamepad.tryCreate() : SdlGamepad.tryCreate();
    }

    public void reconnect(){
        pad = Binds.current = create();
    }

    float dz(float v){
        return Math.abs(v) < Binds.deadzone() ? 0f : v;
    }

    void tick(){
        if(Vars.headless || Vars.player == null) return;

        if(pad == null){
            // re-check every ~3 seconds so plugging in a pad later works
            retryTimer += Time.delta;
            if(retryTimer > 180f){
                retryTimer = 0f;
                pad = Binds.current = create();
            }
            return;
        }

        pad.poll();

        boolean menu = Binds.down(pad, Binds.Action.menu);
        if(menu && !prevMenu && Vars.state.isGame()){
            Vars.ui.paused.show();
        }
        prevMenu = menu;

        if(!Vars.state.isGame() || Vars.state.isPaused()) return;

        Unit unit = Vars.player.unit();
        if(unit == null || unit.dead()) return;

        boolean swap = Binds.swapSticks();
        int mxA = swap ? Gamepad.RX : Gamepad.LX, myA = swap ? Gamepad.RY : Gamepad.LY;
        int axA = swap ? Gamepad.LX : Gamepad.RX, ayA = swap ? Gamepad.LY : Gamepad.RY;

        // Move
        float lx = dz(pad.axis(mxA));
        float ly = -dz(pad.axis(myA));
        if(lx != 0f || ly != 0f){
            Tmp.v1.set(lx, ly).limit(1f);
            float speed = unit.speed() * Binds.speedScale();
            if(Vars.mobile){
                // Mobile input makes the unit chase the camera centre, so push the camera instead;
                // the unit follows it (and stays put when the stick is released).
                float step = speed * Time.delta;
                Core.camera.position.add(Tmp.v1.x * step, Tmp.v1.y * step);
            }else{
                unit.movePref(Tmp.v1.scl(speed));
            }
        }

        // Aim
        float rx = dz(pad.axis(axA));
        float ry = -dz(pad.axis(ayA));
        if(rx != 0f || ry != 0f){
            Tmp.v2.set(rx, ry).limit(1f).scl(Binds.aimRange());
            unit.aim(unit.x + Tmp.v2.x, unit.y + Tmp.v2.y);
        }

        // Shoot
        boolean shoot = Binds.down(pad, Binds.Action.shoot);
        if(shoot){
            unit.isShooting = true;
            Vars.player.shooting = true;
        }else if(prevShoot){
            // only release what we pressed, so mouse/touch shooting keeps working
            unit.isShooting = false;
            Vars.player.shooting = false;
        }
        prevShoot = shoot;

        // Zoom
        if(Binds.down(pad, Binds.Action.zoomOut)) Vars.renderer.setScale(Vars.renderer.getScale() - zoomSpeed * Vars.renderer.getScale());
        if(Binds.down(pad, Binds.Action.zoomIn)) Vars.renderer.setScale(Vars.renderer.getScale() + zoomSpeed * Vars.renderer.getScale());
    }
}
