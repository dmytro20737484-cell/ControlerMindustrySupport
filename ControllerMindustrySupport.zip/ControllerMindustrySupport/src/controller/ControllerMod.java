package controller;

import arc.*;
import arc.math.*;
import arc.util.*;
import mindustry.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.mod.*;

public class ControllerMod extends Mod{
    static final float deadzone = 0.22f, aimRange = 260f, zoomSpeed = 0.03f;

    Gamepad pad;
    boolean prevStart, prevShoot;
    float retryTimer;

    public ControllerMod(){
        Events.on(ClientLoadEvent.class, e -> pad = create());

        // preDraw runs after the game's own input handling, so our values win over the keyboard's zeros.
        Events.run(Trigger.preDraw, this::tick);
    }

    static Gamepad create(){
        return OS.isAndroid ? AndroidGamepad.tryCreate() : SdlGamepad.tryCreate();
    }

    float dz(float v){
        return Math.abs(v) < deadzone ? 0f : v;
    }

    void tick(){
        if(Vars.headless || Vars.player == null) return;

        if(pad == null){
            // re-check every ~3 seconds so plugging in a pad later works
            retryTimer += Time.delta;
            if(retryTimer > 180f){
                retryTimer = 0f;
                pad = create();
            }
            return;
        }

        pad.poll();

        boolean start = pad.button(Gamepad.START);
        if(start && !prevStart && Vars.state.isGame()){
            Vars.ui.paused.show();
        }
        prevStart = start;

        if(!Vars.state.isGame() || Vars.state.isPaused()) return;

        Unit unit = Vars.player.unit();
        if(unit == null || unit.dead()) return;

        // Move
        float lx = dz(pad.axis(Gamepad.LX));
        float ly = -dz(pad.axis(Gamepad.LY));
        if(lx != 0f || ly != 0f){
            Tmp.v1.set(lx, ly).limit(1f).scl(unit.speed());
            unit.movePref(Tmp.v1);
        }

        // Aim
        float rx = dz(pad.axis(Gamepad.RX));
        float ry = -dz(pad.axis(Gamepad.RY));
        if(rx != 0f || ry != 0f){
            Tmp.v2.set(rx, ry).limit(1f).scl(aimRange);
            unit.aim(unit.x + Tmp.v2.x, unit.y + Tmp.v2.y);
        }

        // Shoot (right trigger)
        boolean shoot = pad.axis(Gamepad.RT) > 0.3f;
        if(shoot){
            unit.isShooting = true;
            Vars.player.shooting = true;
        }else if(prevShoot){
            // only release what we pressed, so mouse/touch shooting keeps working
            unit.isShooting = false;
            Vars.player.shooting = false;
        }
        prevShoot = shoot;

        // Zoom (bumpers)
        if(pad.button(Gamepad.LB)) Vars.renderer.setScale(Vars.renderer.getScale() - zoomSpeed * Vars.renderer.getScale());
        if(pad.button(Gamepad.RB)) Vars.renderer.setScale(Vars.renderer.getScale() + zoomSpeed * Vars.renderer.getScale());
    }
}
